﻿using Product_Class;
using Product_Repository;
using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;



namespace Product_Catalogue_Mgmt
{
    internal class Program
    {
        static IProduct_Repository repository = new Product_Repos();
        static void Main(string[] args)
        {
            //one pbi or user story:As a user I want to save Product data into database,so that I can use Later
            //Task 1:FrameWork -EF
            //Task 2:Approach-Code First/Db first
            //Task 3:Setup EF
            //Task 4:Create Entity Classess
            //Task 5:Configure EF
            //Task 6:Map Class to Table
            //Task 7:Create Repository
            //Task 8:Create UI


            /*  ProductDBContext db= new ProductDBContext();*/
            /*db.Database.Log = Console.WriteLine;
            Insert();
            db.Database.Log = Console.WriteLine;*/

            //disconnected approach
            /*    ProductDBContext db1= new ProductDBContext();
                var productToEdit1 = db1.Products.Find(2);*/
            //productToEdit1.Name = "Iphone 15 pro pro";
            //  db1.SaveChanges();

            // Product_Repository.ProductDBContext db1 = new ProductDBContext();

            //select all products and the display product name and category name
            /* ProductDBContext db = new ProductDBContext();
              db.Database.Log = Console.WriteLine;
             var allProducts=from pro in db.Products.Include("category") select pro;
             Product p=new Product();
              Category category = new Category { Name = "laptop" };
              *//*    p.ProductId = 1;
                  p.Name = "Test";
                  p.category = category;
                  db.Products.Add(p);
                  db.Categories.Add(category);
                  db.SaveChanges();
                  Product p1 = new Product();
                  p1.ProductId = 2;
                  p1.Name = "p2";
                  p1.category = category;
                  db.Products.Add(p1);*/
            /* db.SaveChanges();*//*

            foreach (var item in allProducts)
            {
                Console.WriteLine($"{item.Name} and category is {item.category.Name}");
            }*/

            ProductDBContext db = new ProductDBContext();
            Customer customer = new Customer { CustType = "gold", Discount = 20,Email="cust@shop.com",Location="bang",Mobile="423232",Name="Customer i" };
            Supplier supplier = new Supplier { Email="sup@abc.com",Gst="A2324",Location="Bangalore",Mobile="324324"};
            db.peoples.Add(customer);
            db.peoples.Add(supplier);
            db.SaveChanges();
            db.Database.Log=Console.WriteLine;
            var allCustomers=db.peoples.OfType<Customer>().ToList();





            while (true)
            {
                Console.WriteLine("Contact Manager");
                Console.WriteLine("=====================");
                Console.WriteLine("1. Add a new Product");
                Console.WriteLine("2. Get All Products");
                Console.WriteLine("3. Get Product By ID");
                Console.WriteLine("4. update Product");
                Console.WriteLine("5. Delete Product");
                Console.WriteLine("6. Get costliest Product");
                Console.WriteLine("7. Get cheapest Product");
                Console.WriteLine("8. Get Total no of Product");
                Console.WriteLine("9. Exit");
                Console.WriteLine("----------------------");
                Console.Write("Enter your choice [1-9] :");
                int choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1: AddNewProduct(); break;
                    case 2: GetAllProducts(); break;
                    case 3: GetProductById(); break;
                    case 4: UpdateProduct(); break;
                    case 5: DeleteProduct(); break;
                    case 6: GetCostliestProduct(); break;
                    case 7: GetCheapestProduct(); break;
                    case 8: GetTotalProduct(); break;
                    case 9: Environment.Exit(0); break;
                    default: Console.WriteLine("Invalid option"); break;
                }

            }
        }

        private static void GetTotalProduct()
        {
            int count = repository.GetCount();
            Console.WriteLine($"total no of products:{count}");
        }

        private static void GetCheapestProduct()
        {
            var prod = repository.GetCheapestProduct();
            Console.WriteLine(prod.Name + " " + prod.Price + " " + prod.ProductId);
        }

        private static void GetCostliestProduct()
        {
            var prod = repository.GetCostliestProducts();
            Console.WriteLine(prod.Name + " " + prod.Price + " " + prod.ProductId);
        }

        private static void DeleteProduct()
        {
            Console.WriteLine("enter the id of the product");
            int id = int.Parse(Console.ReadLine());
            repository.Delete(id);
        }

        private static void UpdateProduct()
        {
            Console.WriteLine("enter the id of the product that You want to update");
            int id = int.Parse(Console.ReadLine());
            var prod = repository.GetById(id);
            if (prod != null)
            {
                Console.WriteLine("enter the price");
                prod.Price = int.Parse(Console.ReadLine());
                repository.Edit(prod);
            }
            else
            {
                Console.WriteLine("product not found");
            }
        }

        private static void GetProductById()
        {
            Console.WriteLine("enter the id of the product that You want to get");
            int id = int.Parse(Console.ReadLine());
            var prod = repository.GetById(id);
            if (prod != null)
            {
                Console.WriteLine(prod.Name);
                Console.WriteLine(prod.Price);
            }
            else
            {
                Console.WriteLine("product not found");
            }
        }

        private static void GetAllProducts()
        {
            var list = repository.GetAll();
            foreach (var item in list)
            {
                Console.WriteLine(item.Name);
                Console.WriteLine(item.Price);
            }
        }

        private static void AddNewProduct()
        {
            Product p = new Product();
            Console.WriteLine("enter the product");
            p.Name = Console.ReadLine();
            Console.WriteLine("enter the ProductPrice");
            p.Price = int.Parse(Console.ReadLine());
            Console.WriteLine("enter the Productid");
            p.ProductId = int.Parse(Console.ReadLine());
            repository.Save(p);

        }
        private static void EditInDisconnected()
        {
             
        }



    }
}
