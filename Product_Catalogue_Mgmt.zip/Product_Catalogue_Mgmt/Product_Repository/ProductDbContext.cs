﻿using Product_Class;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;

namespace Product_Repository
{
   public class ProductDBContext : DbContext
    {
        //Configur The Database or Map the database
        //Configure-Map the Table
        public ProductDBContext() : base("defaultConnection")
        {

        }
        public DbSet<Product_Class.Product> Products { get; set; }
       // public DbSet<Category> Categories { get; set; }

        //public DbSet<Product_Class.Customer>Customers { get; set; }
        public DbSet<Person> peoples { get; set; }  
    }
}
