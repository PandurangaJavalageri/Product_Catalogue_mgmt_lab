﻿using Product_Class;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Product_Repository
{
    public class Product_Repos:IProduct_Repository
    {
        ProductDBContext db = new ProductDBContext();
    public void Delete(int id)
    {
        var product = (from p in db.Products where p.ProductId == id select p).ToList();
        db.Products.Remove(product[0]);
        db.SaveChanges();
    }

    public void Edit(Product product)
    {


        var productToEdit = (from p in db.Products where p.ProductId == product.ProductId select p).First();
        productToEdit.Name = product.Name;
        productToEdit.ProductId = product.ProductId;
        productToEdit.Price = product.Price;
    }

    public List<Product> GetAll()
    {
        var product = ((from p in db.Products select p).ToList());
        return product;
    }

    public Product GetById(int id)
    {
        var product = (from p in db.Products where p.ProductId == id select p).ToList();
        if (product.Count != 0)
            return product[0];
        return null;
    }

    public Product GetCheapestProduct()
    {
        var product = ((from p in db.Products orderby p.Price select p).First());
        return product;
    }

    public Product GetCostliestProducts()
    {
        var product = ((from p in db.Products orderby p.Price descending select p).First());
        return product;
    }

    public int GetCount()
    {
        return db.Products.Count();
    }

    public void Save(Product p)
    {

        db.Products.Add(p);
        db.SaveChanges();
    }
}
}
