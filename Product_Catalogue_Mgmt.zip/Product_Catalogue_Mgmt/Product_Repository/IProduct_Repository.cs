﻿using Product_Class;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Product_Repository
{
     public interface IProduct_Repository
    {
        void Save(Product product);
        void Delete(int id);
        void Edit(Product product);
        List<Product> GetAll();

        Product GetById(int id);

        Product GetCostliestProducts();
        Product GetCheapestProduct();
        int GetCount();
    }
}
