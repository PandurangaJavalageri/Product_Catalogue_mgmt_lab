﻿
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Product_Class
{
    [Table("tbl_items")]
    public class Product
    {
        
        public int ProductId { get; set; }
        [Required]
        [MaxLength(100)]
        public string Name { get; set; }
        public int Price { get; set; }

        [NotMapped]
        public int SellingPrice {  get; set; }
        public string Brand { get; set; }

        public string Country {  get; set; }
        public bool InStock {  get; set; }

        //[foreignkey("Category")]
       public Category category { get; set; }

        public List<Supplier> Suppliers { get; set; }=new List<Supplier>();

    
    }
    public class Category
    {
        public int CategoryId { get; set;}

        [Required]
        [MaxLength(100)]
        public string Name { get; set; }

        public List<Product> Products { get; set; }=new List<Product>();
        
    }
    public class Supplier:Person
    {
        //public int SupplierId { get; set; }
        
        public string Gst {  get; set; }
        public string tradeLicense {  get; set; }
        public virtual List<Product> Products { get; set;}=new List<Product>();
    }
    public class Person
    {
        public int PersonId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public string Location { get; set; }
    }
    public class Customer : Person
    {
        public int Discount { get; set; }
        public string CustType {  get; set; }
    }
}
